Bagini  Luca    923969
Come specificato nei commenti del programma, 
la lista vuota viene considerata come corrispondente 
ad epsilon e non al linguaggio vuoto.